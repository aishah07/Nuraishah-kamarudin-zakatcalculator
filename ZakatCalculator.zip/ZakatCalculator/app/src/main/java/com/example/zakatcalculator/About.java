package com.example.zakatcalculator;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.widget.Toolbar;

public class About extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    Toolbar aboutToolBar;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        super.equals(savedInstanceState);
        setContentView(R.layout.activity_about);

        aboutToolBar = aboutToolBar.findViewById(R.id.about_toolbar);
        getSupportActionBar();
        getSupportActionBar().setTitle("About");

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
    }

    public void setContentView(int activityAbout) {
    }

    public ActionBar getSupportActionBar() {
        // Your custom implementation here
        return super.getSupportActionBar();
    }

    public boolean onOptionsItemSelected(MenuItem item){
        if(item.getItemId() == android.R.id.home){
            super.onBackPressed();
        }
        return true;
    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
