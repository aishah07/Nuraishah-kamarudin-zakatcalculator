package com.example.zakatcalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

public class MainActivity<spinner> extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    Toolbar toolbar;
    EditText editTextGoldValue, editTextGoldGram;
    Button btncalculatezakat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        View myToolbar = findViewById(R.id.my_toolbar);
        getSupportActionBar().setTitle("Zakat Calculator");

        Spinner spinnerOptions = findViewById(R.id.spinner_options);
        ArrayAdapter<CharSequence> adapterOptions = ArrayAdapter.createFromResource(this, R.array.spinner_options, android.R.layout.simple_spinner_item);
        adapterOptions.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerOptions.setAdapter(adapterOptions);
        spinnerOptions.setOnItemSelectedListener(this);

        editTextGoldValue = findViewById(R.id.editTextGoldValue);
        editTextGoldGram = findViewById(R.id.editTextGoldGram);
        btncalculatezakat = findViewById(R.id.btncalculatezakat);

        btncalculatezakat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateZakat();
            }
        });

    }

    @Override

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override

    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.item_share){
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_TEXT, "Please use my application - https://github.com/nuraishah");
            startActivity(Intent.createChooser(shareIntent, null));
            return true;
        }
        else if (item.getItemId() == R.id.item_about){
            Intent aboutIntent = new Intent(this , About.class);
            startActivity(aboutIntent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void calculateZakat(){
        try {
            double goldWeight = Double.parseDouble(editTextGoldGram.getText().toString());
            Spinner spinnerOptions = findViewById(R.id.spinner_options);
            String selectedOption = (String) spinnerOptions.getSelectedItem();

            String goldType =(String) spinnerOptions.getSelectedItem();
            double currentGoldValue = Double.parseDouble(editTextGoldValue.getText().toString());

            double totalGoldValue = goldWeight - getXValue(goldType);
            double zakatPayableValue = Math.max(totalGoldValue, 0) * currentGoldValue;
            double totalZakat = 0.025 * zakatPayableValue;

            TextView totalGold = findViewById(R.id.TGold);
            totalGold.setText("Total value of the gold in Gram: " +String.format(" % 2f" , totalGoldValue));

            TextView totalzakatpayable = findViewById(R.id.TZPayable);
            totalzakatpayable.setText("Total zakat payable is RM :" +String.format(" % 2f" , zakatPayableValue));

            TextView totalzakat = findViewById(R.id.TZakat);
            totalzakat.setText("Total zakat is RM: "+String.format(" % 2f", totalZakat));


        }
        catch (NumberFormatException e){
            Toast.makeText(this, "Please enter value of gold and number of weight gold", Toast.LENGTH_SHORT).show();
        }

    }

    private double getXValue(String goldType){
        double XValue = 0.0;
        if ("Keep".equals(goldType)) {
            XValue = 85.0;
        }
        else if ("Wear".equals(goldType)){
            XValue = 200.0;
        }
        return XValue;
    }

    @Override

    public void onItemSelected(AdapterView<?> parent, View view, int position, long id){

    }
    @Override

    public void onNothingSelected(AdapterView<?> parent){

    }

}